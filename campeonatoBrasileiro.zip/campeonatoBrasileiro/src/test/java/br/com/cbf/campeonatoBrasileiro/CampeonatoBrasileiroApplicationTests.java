package br.com.cbf.campeonatoBrasileiro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampeonatoBrasileiroApplicationTests {

	@Test
	void contextLoads() {
	}

}
