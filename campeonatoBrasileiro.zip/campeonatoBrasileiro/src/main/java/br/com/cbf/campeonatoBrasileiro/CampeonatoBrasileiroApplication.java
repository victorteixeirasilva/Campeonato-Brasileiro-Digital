package br.com.cbf.campeonatoBrasileiro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampeonatoBrasileiroApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampeonatoBrasileiroApplication.class, args);
	}

}
